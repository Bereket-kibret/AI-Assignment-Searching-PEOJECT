package search;

import java.util.*;

public class BestFirstSearch {
    public static Deque<Graph> search(Graph graph, Graph target){
        Deque<Graph> openList = new LinkedList<>();
        openList.add(graph);
        if (Objects.equals(graph.name, target.name)){
            return openList;
        }
        while (!graph.children.isEmpty()){
            for (int i=0; i<graph.children.size(); i++){
                if (isMinimum(graph.children.get(i),graph.children)){
                    graph = graph.children.get(i);
                    openList.add(graph);
                    if (Objects.equals(graph.name, target.name)){
                        return openList;
                    }
                    // exit for loop, checking for next child
                    i=graph.parent.children.size();
                }
            }
        }
        return openList;
    }
    private static boolean isMinimum( Graph target, List<Graph> siblings){
        for (int i=0; i<siblings.size(); i++){
            if (target.HNValue >= siblings.get(i).HNValue && !Objects.equals(target.name, siblings.get(i).name)){
                return false;
            }
        }
        return true;
    }
}
