package search;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
//        Graph parent = GraphInfo.generateGraph();
//        //search.GraphInfo.displayGraph(parent);
//        DepthFirstSearch.display(parent);
//        BreadthFirstSearch.displayAll(parent);
//        Graph target = parent.children.get(2).children.get(1);
//        GraphInfo.displayGraphList(GraphInfo.getGraphPath(target));
//
//        PathCostGenerator.generatePathCost(parent);
//        HNGenerator.generateHNForAS(parent, target);
//        GraphInfo.displayGraphList(parent);
//
//        // Breadth-First search
//        System.out.println("Breadth-First  Search Finding "+ target.name);
//        Deque<Graph> breadthFirst = BreadthFirstSearch.search(parent, target);
//        if (!breadthFirst.isEmpty()){
//            if (!Objects.equals(breadthFirst.peekLast().name, target.name)){
//                System.out.println("Target not found.");
//            }else {
//                GraphInfo.displayGraphList(breadthFirst);
//            }
//        }
//
//        // Depth-First search
//        System.out.println("Depth-First Search Finding "+ target.name);
//        Deque<Graph> depthFirst = DepthFirstSearch.search(parent, target);
//        if (!depthFirst.isEmpty()){
//            if (!Objects.equals(depthFirst.peekLast().name, target.name)){
//                System.out.println("Target not found.");
//            }else {
//                GraphInfo.displayGraphList(depthFirst);
//            }
//        }
//
//        // A* search algorithm
//        System.out.println("A* Search Finding "+ target.name);
//        Deque<Graph> ASearchList = ASearch.search(parent, target);
//        if (!ASearchList.isEmpty()){
//            if (!Objects.equals(ASearchList.peekLast().name, target.name)){
//                System.out.println("Target not found.");
//            }else {
//                GraphInfo.displayGraphList(ASearchList);
//            }
//        }
//
//        // Best-First search
//        System.out.println("Best-First Search Finding "+ target.name);
//        Deque<Graph> bestFirst = BestFirstSearch.search(parent, target);
//        if (!bestFirst.isEmpty()){
//            if (!Objects.equals(bestFirst.peekLast().name, target.name)){
//                System.out.println("Target not found.");
//            }else {
//                GraphInfo.displayGraphList(bestFirst);
//            }
//        }
        SwingUtilities.invokeLater(() -> new GUI().setVisible(true));
    }
}












