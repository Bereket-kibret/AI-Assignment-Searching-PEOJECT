package search;

import java.util.Queue;

public class PathCostGenerator {
    public static void generatePathCost(Graph parent){
        Queue<Graph> graphList = GraphInfo.getAllGraphList(parent);
        while (!graphList.isEmpty()){
            graphList.poll().pathCost = (int)((Math.random() * 100)+100);
        }
    }
}
