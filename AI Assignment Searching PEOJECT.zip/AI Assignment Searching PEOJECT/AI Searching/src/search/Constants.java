package search;

public class Constants {
    public static final double GRAPH_WIDTH = 1500;
    public static final double GRAPH_HEIGHT = 2000;
    public static final int CHILD_SIZE= 2;
    public static final int NODE_SIZE = 14;
}
