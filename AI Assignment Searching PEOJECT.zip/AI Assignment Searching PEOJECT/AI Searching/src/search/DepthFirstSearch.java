package search;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Objects;

public class DepthFirstSearch {
    public static Deque<Graph> search(Graph parent, Graph target){
        Deque<Graph> graphList = new LinkedList<>();
        Deque<Graph> openList = new LinkedList<>();
        graphList.add(parent);
        while (!graphList.isEmpty()){
            openList.add(graphList.peekFirst());
            if (Objects.equals(openList.peekLast().name, target.name)){
                return openList;
            }
            Graph parentCopy = graphList.pollFirst();
            for (int i=(parentCopy.children.size()-1); i>=0; i--){
                graphList.push(parentCopy.children.get(i));
            }
        }
        return openList;
    }
    public static void display(Graph parent){
        Deque<Graph> graphList = new LinkedList<>();
        Deque<Graph> openList = new LinkedList<>();
        graphList.add(parent);
        while (!graphList.isEmpty()){
            openList.add(graphList.peek());
            Graph parentCopy = graphList.poll();
            for (int i=(parentCopy.children.size()-1); i>=0; i--){
                graphList.push(parentCopy.children.get(i));
            }
        }
        while (!openList.isEmpty()){
            System.out.println(openList.poll().name);
        }
    }
    public static void displayAll(Graph parent){
        System.out.println(parent.name);
        for (int i=0; i<parent.children.size(); i++){
            displayAll(parent.children.get(i));
        }
    }
}
