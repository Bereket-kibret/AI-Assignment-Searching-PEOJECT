package search;

import java.util.*;

public class HNGenerator {
    public static void generateHNValue(Graph graph, Graph target){
        Deque<Graph> targetPath = GraphInfo.getGraphPath(target);
        int targetDepth = targetPath.size();
        Queue<Graph> graphList = GraphInfo.getAllGraphList(graph);
        // generating random hn value
        while (!graphList.isEmpty()){
            // minimum h(n) value
            int minimumHN = (targetDepth * 10) - (graphList.peek().depth * 10);
            if (minimumHN < 0){
                minimumHN *= (-1);
            }
            // random number between min and min + random from 2-5
            int randomHN = minimumHN + (int)(Math.random() * 8) + 2;
            graphList.peek().HNValue = randomHN;
            graphList.poll();
        }
        // generating HN value that can lead to target
        while (!targetPath.isEmpty()){
            Graph parent = targetPath.poll();
            if (!targetPath.isEmpty()){
                while (isMinimum(targetPath.peek(), parent.children)){
                    targetPath.peek().HNValue -= 3;
                }
            }
        }
    }
    private static boolean isMinimum( Graph target, List<Graph> siblings){
        for (int i=0; i<siblings.size(); i++){
            if (target.HNValue >= siblings.get(i).HNValue && !Objects.equals(target.name, siblings.get(i).name)){
                return true;
            }
        }
        return false;
    }
    public static void generateHNForAS(Graph graph, Graph target){
        Deque<Graph> targetPath = GraphInfo.getGraphPath(target);
        int targetDepth = targetPath.size();
        Queue<Graph> graphList = GraphInfo.getAllGraphList(graph);
        // generating random hn value
        while (!graphList.isEmpty()){
            // minimum h(n) value
            int depthDiff = targetDepth - graphList.peek().depth;
            if (depthDiff < 0){
                depthDiff *= (-1);
            }
            int minimumHN = depthDiff * 50 + 200;

            // random number between min and min + random from 2-5
            int randomHN = minimumHN + (int)(Math.random() * 50);
            graphList.peek().HNValue = randomHN;
            graphList.poll();
        }
        // generating HN value that can lead to target
        while (!targetPath.isEmpty()) {
            Graph parent = targetPath.poll();
            if (!targetPath.isEmpty()) {
                while (!isSumMinimum(targetPath.peek(), parent.children)) {
                    targetPath.peek().HNValue -= 15;
                }
            }
        }
    }

    private static boolean isSumMinimum(Graph target, List<Graph> siblings) {
        for (int i=0; i<siblings.size(); i++){
            int targetTotalHN = target.HNValue + target.getTotalPathCost();
            int siblingTotalHN = siblings.get(i).HNValue + siblings.get(i).getTotalPathCost();
            if (targetTotalHN >= siblingTotalHN && !Objects.equals(target.name, siblings.get(i).name)){
                return false;
            }
        }
        return true;
    }
}
