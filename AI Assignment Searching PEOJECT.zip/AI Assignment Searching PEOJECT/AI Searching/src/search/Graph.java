package search;

import java.util.ArrayList;
import java.util.List;

public class Graph {
    public String name;
    public List<Graph> children = new ArrayList<>();
    public Graph parent = null;
    public int pathCost = 0, HNValue = 0, depth = 0;

    public Graph(String name){
        this.name= name;
    }
    public int getTotalPathCost(){
        int totalPathCost = 0;
        if (parent != null){
            totalPathCost = (pathCost + parent.getTotalPathCost());
        }
        return totalPathCost;
    }
}
