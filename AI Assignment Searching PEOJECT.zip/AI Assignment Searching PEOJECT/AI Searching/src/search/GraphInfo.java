package search;

import java.util.*;

public class GraphInfo {
    public static Queue<Graph> graphList;
    public static Queue<Graph> needChild;

    public static Graph generateGraph(){
        graphList = new LinkedList<>();
        needChild = new LinkedList<>();
        Graph parent = new Graph("S");
        needChild.add(parent);
        for (int i=0; i<Constants.NODE_SIZE; i++){
            Graph node = new Graph(""+ i);
            graphList.add(node);
        }
        while (!graphList.isEmpty() && !needChild.isEmpty()){
            for (int i=0; i<Constants.CHILD_SIZE; i++){
                if (!graphList.isEmpty()){
                    // giving parent to the child using graphList before adding to
                    // needChild
                    graphList.peek().parent = needChild.peek();
                    graphList.peek().depth = needChild.peek().depth+1;
                    needChild.peek().children.add(graphList.peek());
                    needChild.add(graphList.peek());
                    graphList.poll();
                }
            }
            needChild.poll();
        }
        return parent;
    }
    public static Queue<Graph> getAllGraphList(Graph graph){
        Queue<Graph> graphList = new LinkedList<>();
        Queue<Graph> openList = new LinkedList<>();
        graphList.add(graph);
        while (!graphList.isEmpty()){
            for (int i =0; i<graphList.peek().children.size(); i++){
                graphList.add(graphList.peek().children.get(i));
            }
            openList.add(graphList.poll());
        }
        return openList;
    }
    public static Graph getTarget(String targetName, Graph fromGraph){
        Queue<Graph> allGraphList = getAllGraphList(fromGraph);

        while (!allGraphList.isEmpty()){
            Graph graph = allGraphList.poll();
            if (Objects.equals(graph.name, targetName)){
                return graph;
            }
        }
        return null;
    }
    public static Deque<Graph> getGraphPath(Graph target){
        Deque<Graph> graphList = new LinkedList<>();
        graphList.push(target);
        while (target.parent != null){
            graphList.push(target.parent);
            target = target.parent;
        }
//        while (!graphList.isEmpty()){
//            System.out.println(graphList.poll().name);
//        }
        return graphList;
    }
    public static void displayGraphWithHN(Graph graph){
        Queue<Graph> allGraph = getAllGraphList(graph);
        while (!allGraph.isEmpty()){
            Graph graphCopy = allGraph.poll();
            System.out.println(graphCopy.name +"  "+ graphCopy.HNValue);
        }
    }
    public static void displayGraphList(Deque<Graph> graphList){
        System.out.println("Node   h(n)    g(n)    T(g(n))     T(g(n))+h(n)");

        for (int i =0; i<graphList.size(); i++){
            Graph graph = graphList.peek();
            int totalPathCost = graph.getTotalPathCost();
            int HNAndPathCost = graph.HNValue + totalPathCost;
            System.out.println(graph.name + "       "+ graph.HNValue +"      "+ graph.pathCost+"       "+
                    totalPathCost + "       "+ HNAndPathCost);
        }
    }
    public static void displayGraphList(Graph parent){
        Queue<Graph> graphList = getAllGraphList(parent);
        System.out.println("Node   h(n)    g(n)    T(g(n))     T(g(n))+h(n)");
        while (!graphList.isEmpty()){
            Graph graph = graphList.poll();
            int totalPathCost = graph.getTotalPathCost();
            int HNAndPathCost = graph.HNValue + totalPathCost;
            System.out.println(graph.name + "       "+ graph.HNValue +"      "+ graph.pathCost+"       "+
                    totalPathCost + "       "+ HNAndPathCost);
        }
    }
}
