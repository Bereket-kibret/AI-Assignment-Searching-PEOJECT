package search;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.Deque;
import java.util.Objects;

import search.*;

public class GUI extends JFrame implements ActionListener {
    Graph mainParent = GraphInfo.generateGraph();
    Graph target = mainParent.children.get(1).children.get(1);
    boolean findSearch = false, searchStart = false;
    Deque<Graph> openList = null, targetPath = null;
    JTextField targetField;
    JTextField fromName;
    JTextField toName;
    long excutiontime =0,startTime,endTime;
    String targetIndicator="";
    public GUI(){

        setTitle("AI Searching");
        double graphWidth = Constants.GRAPH_WIDTH;
        double graphHeight = Constants.GRAPH_HEIGHT;

        JPanel canvas = new JPanel(){
            @Override
            protected void paintComponent(Graphics g){
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                double startMapX = 1300;
                double startMapY = 40;
                double mapWidth = 200;
                double itemHeight = 20;


                // for instruction purpose
                Rectangle2D container = new Rectangle2D.Double(startMapX,startMapY,mapWidth,80);
                Rectangle2D hn = new Rectangle2D.Double(startMapX,startMapY,mapWidth,20);
                Rectangle2D gn = new Rectangle2D.Double(startMapX,startMapY+20,mapWidth,20);
                Rectangle2D totalGn = new Rectangle2D.Double(startMapX,startMapY+40,mapWidth,20);
                Rectangle2D totalGnPlusHn = new Rectangle2D.Double(startMapX,startMapY+60,mapWidth,20);
                Rectangle2D node = new Rectangle2D.Double(startMapX,startMapY+80,mapWidth,20);

                g2.setColor(Color.ORANGE);
                g2.fill(container);
                g2.fill(hn);
                g2.setColor(Color.GREEN);
                g2.fill(gn);
                g2.setColor(Color.YELLOW);
                g2.fill(totalGn);
                g2.setColor(Color.RED);
                g2.fill(totalGnPlusHn);
                g2.setColor(Color.blue);
                g2.fill(node);

                g2.setColor(Color.BLACK);
                g2.setFont(new Font("Serif", Font.BOLD, 20));
                int textStartX = (int) startMapX+10;
                g2.drawString("Instructions",textStartX+20,(int) startMapY-10);
                g2.drawString("Herustic value h(n)", textStartX,(int) startMapY+18);
                g2.drawString("Path Cost",textStartX,(int) startMapY+38);
                g2.drawString("Total Path Cost g(n)",textStartX,(int) startMapY+58);
                g2.drawString("g(n) + h(n)", textStartX,(int) startMapY+75);
                g2.setColor(Color.white);
                g2.drawString("Node", textStartX,(int) startMapY+98);

                g2.setColor(Color.BLACK);
                g2.drawString("Expanded node:", 30,100);
                g2.drawString(openList!=null && searchStart? openList.size()+"": "", 220,100);
                g2.drawString("Solution path Cost:", 30,120);
                double totalPathCost = 0;
                if (target!= null && searchStart){
                    if(target.getTotalPathCost() == 0){
                        totalPathCost = GraphInfo.getGraphPath(target).size();
                    }else{
                        totalPathCost = target.getTotalPathCost();
                    }
                }
                g2.drawString(totalPathCost+"", 220,120);
                g2.drawString("Execution Time:", 30,140);
                g2.drawString(excutiontime+" nanoS", 220,140);
                if(openList == null){
                    targetIndicator = "";
                }else if (Objects.equals(openList.peekLast().name, target.name)){
                    targetIndicator = "Target Found";
                    g2.setColor(Color.BLACK);
                }else{
                    targetIndicator = "Target Not Found";
                    g2.setColor(Color.red);
                }
                g2.drawString(targetIndicator, 30,160);

                double allowedSpace = graphWidth;
                double parentCenterY = 165;
                double parentCenterX = allowedSpace/2;
                drawGraph(g2, mainParent, parentCenterX, parentCenterY, allowedSpace,0);

            }
        };

        canvas.setPreferredSize(new Dimension((int) graphWidth,(int) graphHeight));

        JScrollPane scrollPane = new JScrollPane(canvas);


        JPanel controller = new JPanel();
        JButton generatePathCost = new JButton("Generate PathCost");
        generatePathCost.addActionListener(this);
        JButton generateHnForBestFS = new JButton("Generate h(n) for Best First Search");
        generateHnForBestFS.addActionListener(this);
        JButton generateHnForAS = new JButton("Generate h(n) for A* Search");
        generateHnForAS.addActionListener(this);
        JButton useBFS = new JButton("Use Breadth First Search");
        useBFS.addActionListener(this);
        JButton useDFS = new JButton("Use Depth First Search");
        useDFS.addActionListener(this);
        JButton useBestFS = new JButton("Use Best First Search");
        useBestFS.addActionListener(this);
        JButton useAS = new JButton("Use A* search");
        useAS.addActionListener(this);

        JPanel nodeController = new JPanel(new GridLayout(2,1,10,0));
        JPanel targetChanger = new JPanel();
        targetField = new JTextField(target.name);
        JButton changeTarget = new JButton("Change Target");
        changeTarget.addActionListener(this);
        targetChanger.add(targetField);
        targetChanger.add(changeTarget);
        nodeController.add(targetChanger);

        JPanel nodeChanger = new JPanel(new GridLayout(1,3,0,10));

        JPanel nodeContainer = new JPanel(new GridLayout(2,1,3,0));
        nodeContainer.add(new JLabel("Node"));
        fromName = new JTextField();
        nodeContainer.add(fromName);
        nodeChanger.add(nodeContainer);

        JPanel nodeContainer2 = new JPanel(new GridLayout(2,1,3,0));
        nodeContainer2.add(new JLabel("To"));
        toName = new JTextField();
        nodeContainer2.add(toName);
        nodeChanger.add(nodeContainer2);

        JButton renameBtn = new JButton("Rename");
        renameBtn.addActionListener(this);

        nodeChanger.add(renameBtn);
        nodeController.add(nodeChanger);


        controller.add(generatePathCost);
        controller.add(generateHnForBestFS);
        controller.add(generateHnForAS);
        controller.add(useBFS);
        controller.add(useDFS);
        controller.add(useBestFS);
        controller.add(useAS);
        controller.add(nodeController);
        add(controller, BorderLayout.NORTH);
        add(scrollPane,BorderLayout.CENTER);


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1750, 800);
        setLocationRelativeTo(null);

    }

    private void drawGraph(Graphics2D g, Graph parent, double parentCenterX, double parentCenterY,Double allowedGap, int index) {
        // for connector line
        if (!parent.children.isEmpty()){
            double childAllowedSpace = allowedGap/parent.children.size();
            double childCenterY = parentCenterY + 125;
            double childAllowedHalf = childAllowedSpace/2;
            for (int i =0; i<parent.children.size(); i++){
                double childCenterX = childAllowedHalf + ((childAllowedSpace)*i) + allowedGap*index;
                System.out.println(parent.children.get(i).name +"   "+childCenterX +"   "+
                        childCenterY+"  "+ childAllowedSpace);
                g.setColor(Color.BLACK);
                if (findSearch && openList.contains(parent.children.get(i))){
                    g.setColor(Color.RED);
                }
                if (findSearch && targetPath.contains(parent.children.get(i))){
                    g.setColor(Color.GREEN);
                }
                g.setStroke(new BasicStroke(3));
                g.drawLine((int) parentCenterX, (int)parentCenterY-40, (int)childCenterX, (int)childCenterY);
            }
        }
        // for the child
        if (!parent.children.isEmpty()){
            double childAllowedSpace = allowedGap/parent.children.size();
            double childCenterY = parentCenterY + 165;
            double childAllowedHalf = childAllowedSpace/2;
            for (int i =0; i<parent.children.size(); i++){
                double childCenterX = childAllowedHalf + ((childAllowedSpace)*i) + allowedGap*index;
                System.out.println(parent.children.get(i).name +"   "+childCenterX +"   "+
                        childCenterY+"  "+ childAllowedSpace);
                drawGraph(g, parent.children.get(i),childCenterX,childCenterY,childAllowedSpace, index*Constants.CHILD_SIZE+i);
            }
        }
        double startX = parentCenterX - 20;
        double startY = parentCenterY - 150;
        double width = 40;
        Rectangle2D container = new Rectangle2D.Double(startX,startY,width,80);
        Rectangle2D hn = new Rectangle2D.Double(startX,startY,width,20);
        Rectangle2D gn = new Rectangle2D.Double(startX,startY+20,width,20);
        Rectangle2D totalGn = new Rectangle2D.Double(startX,startY+40,width,20);
        Rectangle2D totalGnPlusHn = new Rectangle2D.Double(startX,startY+60,width,20);


        Ellipse2D node = new Ellipse2D.Double(startX, startY+85,width,width);
        g.setColor(Color.BLUE);
        if (findSearch && openList.contains(parent)){
            g.setColor(Color.RED);
        }
        if (findSearch && targetPath.contains(parent)){
            g.setColor(Color.GREEN);
        }
        if (findSearch && !targetPath.isEmpty() && targetPath.peekLast().name == parent.name){
            g.setColor(Color.GREEN);
            findSearch = false;
        }
        g.fill(node);
        g.setColor(Color.ORANGE);
        g.fill(container);
        g.fill(hn);
        g.setColor(Color.GREEN);
        g.fill(gn);
        g.setColor(Color.YELLOW);
        g.fill(totalGn);
        g.setColor(Color.RED);
        g.fill(totalGnPlusHn);

        g.setColor(Color.BLACK);
        g.setFont(new Font("Serif", Font.BOLD, 20));
        g.drawString(" "+parent.HNValue, (int) startX, (int)startY+20);
        g.drawString(" "+parent.pathCost, (int) startX, (int)startY+40);
        g.drawString(" "+parent.getTotalPathCost(), (int) startX, (int)startY+60);
        g.drawString(" "+(parent.getTotalPathCost() + parent.HNValue), (int) startX, (int)startY+80);

        g.setColor(Color.WHITE);
        g.drawString(" "+parent.name, (int) startX, (int)startY+110);
    }

    @Override
    public void paintComponents(Graphics g) {
        super.paintComponents(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.BLUE);
        g2d.fillOval(50,50,60,70);
        g2d.drawOval(50,50,60,100);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String clickedButton = e.getActionCommand();
        switch (clickedButton){
//            case "Generate Graph":
//            {
//                mainParent = GraphInfo.generateGraph();
//                Graph target = mainParent.children.get(1).children.get(1).children.get(0);
//                repaint();
//            }
//            break;
            case "Generate h(n) for Best First Search":
            {
                HNGenerator.generateHNValue(mainParent,target);
                repaint();
            }
            break;
            case "Generate h(n) for A* Search":
            {
                HNGenerator.generateHNForAS(mainParent,target);
                repaint();
            }
            break;
            case "Generate PathCost":
            {
                PathCostGenerator.generatePathCost(mainParent);
                repaint();
            }
            break;
            case "Use Breadth First Search":
            {
                startTime = System.nanoTime();
                openList = BreadthFirstSearch.search(mainParent, target);
                if (Objects.equals(target.name, openList.peekLast().name)){
                    target = openList.peekLast();
                }
                targetPath = GraphInfo.getGraphPath(target);
                findSearch = true;
                searchStart = true;
                endTime = System.nanoTime();
                excutiontime = endTime-startTime;
                repaint();
            }
            break;
            case "Use Depth First Search":
            {
                startTime = System.nanoTime();
                openList = DepthFirstSearch.search(mainParent,target);
                if (Objects.equals(target.name, openList.peekLast().name)){
                    target = openList.peekLast();
                }
                targetPath = GraphInfo.getGraphPath(target);
                findSearch = true;
                searchStart = true;
                endTime = System.nanoTime();
                excutiontime = endTime-startTime;
                repaint();
            }
            break;
            case "Use Best First Search":
            {
                startTime = System.nanoTime();
                openList = BestFirstSearch.search(mainParent,target);
                if (Objects.equals(target.name, openList.peekLast().name)){
                    target = openList.peekLast();
                }
                targetPath = GraphInfo.getGraphPath(target);
                findSearch = true;
                searchStart = true;
                endTime = System.nanoTime();
                excutiontime = endTime-startTime;
                repaint();
            }
            break;
            case "Use A* search":
            {
                startTime = System.nanoTime();
                openList = ASearch.search(mainParent,target);
                if (Objects.equals(target.name, openList.peekLast().name)){
                    target = openList.peekLast();
                }
                targetPath = GraphInfo.getGraphPath(target);
                findSearch = true;
                searchStart = true;
                endTime = System.nanoTime();
                excutiontime = endTime-startTime;
                repaint();
            }
            break;
            case "Change Target":
            {
                target = GraphInfo.getTarget(targetField.getText(), mainParent);
            }
            break;
            case "Rename":
            {
                Graph targetedGraph = GraphInfo.getTarget(fromName.getText(), mainParent);
                targetedGraph.name = toName.getText();
                repaint();
            }
            break;
            default:
                break;
        }
    }
}
