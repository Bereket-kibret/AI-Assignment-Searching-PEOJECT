package search;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Queue;

public class BreadthFirstSearch {
    public static Deque<Graph> search(Graph graph, Graph target){
        Deque<Graph> graphList = new LinkedList<>();
        Deque<Graph> openList = new LinkedList<>();
        graphList.add(graph);

        while (!graphList.isEmpty()){
            for (int i =0; i<graphList.peek().children.size(); i++){
                graphList.add(graphList.peek().children.get(i));
            }
            openList.add(graphList.poll());
            if (Objects.equals(openList.peekLast().name, target.name)){
                return openList;
            }
        }
        return openList;
    }
    public static void displayAll(Graph graph){
        Queue<Graph> graphList = new LinkedList<>();
        Queue<Graph> openList = new LinkedList<>();
        graphList.add(graph);
        while (!graphList.isEmpty()){
            for (int i =0; i<graphList.peek().children.size(); i++){
                graphList.add(graphList.peek().children.get(i));
            }
            openList.add(graphList.poll());
        }
        while (!openList.isEmpty()){
            System.out.println(openList.poll().name);
        }
    }

}
